package com.capgemini.uas.dao;

import com.capgemini.uas.bean.User;
import com.capgemini.uas.exception.UASException;

public interface IUserDAO {

	User getUserByName(String userName) throws UASException;
}
