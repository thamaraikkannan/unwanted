package com.capgemini.uas.exception;

public class UASException extends Exception{
	public UASException(String message) {
		super(message);
	}

}
