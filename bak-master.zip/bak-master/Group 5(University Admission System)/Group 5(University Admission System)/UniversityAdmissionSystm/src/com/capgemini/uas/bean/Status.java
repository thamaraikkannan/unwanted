package com.capgemini.uas.bean;

public enum Status {
ACCEPTED,REJECTED;
}
