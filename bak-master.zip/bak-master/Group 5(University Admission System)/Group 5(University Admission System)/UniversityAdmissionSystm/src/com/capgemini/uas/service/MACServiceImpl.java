package com.capgemini.uas.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ApplicationStatus;
import com.capgemini.uas.dao.IUniversityDAO;
import com.capgemini.uas.dao.UniversityDAOImpl;
import com.capgemini.uas.exception.UASException;

public class MACServiceImpl implements IMACService {

	Logger logger1 = Logger.getRootLogger();

	public List<Application> getAllApplications(int scheduledPgmId)
			throws UASException {
		List<Application> applicationList = new ArrayList<Application>();
		IUniversityDAO universityDAO = null;
		universityDAO = new UniversityDAOImpl();
		applicationList = universityDAO.getAllApplications(scheduledPgmId);
		return applicationList;
	}

	public boolean updateStatus(ApplicationStatus application) throws UASException {
		//System.out.println("in service");
		//int noOfUpdates = 0;
		UniversityDAOImpl universityDAO =  new UniversityDAOImpl();
		
		//System.out.println("in service1");
		//noOfUpdates = universityDAO.updateStatus(application);
		//System.out.println("in service2");
		return  universityDAO.updateStatus(application);
	}

	public ApplicationStatus getApplicationStatus(Integer applicationId)
			throws UASException {
		UniversityDAOImpl universityDAO = new UniversityDAOImpl();

		return universityDAO.getApplicationStatus(applicationId);
	}

	
	}
	

