package com.capgemini.uas.bean;

public class ScheduledProgramID {

	private String scheduledPgmId;
	private String scheduledPgmName;
	private String location;
	private int session;

	public String getScheduledPgmId() {
		return scheduledPgmId;
	}

	public void setScheduledPgmId(String scheduledPgmId) {
		this.scheduledPgmId = scheduledPgmId;
	}

	public String getScheduledPgmName() {
		return scheduledPgmName;
	}

	public void setScheduledPgmName(String scheduledPgmName) {
		this.scheduledPgmName = scheduledPgmName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getSession() {
		return session;
	}

	public void setSession(int session) {
		this.session = session;
	}

	
}
