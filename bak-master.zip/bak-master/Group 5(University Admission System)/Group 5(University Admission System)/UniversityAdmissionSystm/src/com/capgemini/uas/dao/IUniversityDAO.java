package com.capgemini.uas.dao;

import java.util.List;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ApplicationStatus;
import com.capgemini.uas.bean.RetrieveAllDetails;
import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.bean.ScheduledProgramID;
import com.capgemini.uas.exception.UASException;

public interface IUniversityDAO {

	public List<ProgramsScheduled> getProgramSchedule() throws UASException;

	public int addApplicantDetails(Application application)
			throws UASException;

	public List<Application> getAllApplications(int scheduledPgmId)
			throws UASException;

	public boolean updateStatus(ApplicationStatus application) throws UASException;
	
	
	public List<ScheduledProgramID> getScheduledProgramIdName()
			throws UASException;

	public ApplicationStatus getApplicationStatus(Integer applicationId)
			throws UASException;

	public List<ProgramsOffered> getProgramsOffered() throws UASException;

	public List<ProgramsScheduled> getProgramScheduledByDate(
			String startDate, String endDate) throws UASException;
 
	public int deleteScheduledPgm(String pgmId) throws UASException;

	public int deleteOfferedProgram(String programName) throws UASException;

	public int updateProgramsOffered(ProgramsOffered programsOffered)
			throws UASException;

	public int addToSchedule(ProgramsScheduled scheduledBean)
			throws UASException;

	public List<RetrieveAllDetails> getProgramDetails() throws UASException;

	public int addToOffered(ProgramsOffered offeredBean)
			throws UASException;

	

}
