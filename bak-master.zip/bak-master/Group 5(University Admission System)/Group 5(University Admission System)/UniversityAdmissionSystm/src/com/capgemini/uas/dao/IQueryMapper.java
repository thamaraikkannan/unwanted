package com.capgemini.uas.dao;

public interface IQueryMapper {

	// User Table for Login
	public final String GETUSER = "SELECT * FROM users where login_id=?";

	// Auto Generating Application Id
	public final String GETAPPIDSEQ = "SELECT application_id_seq.NEXTVAL FROM DUAL";

	// Insert Application Details
	public final String INSERTAPPLICATION = "INSERT INTO application (application_id,full_name, date_of_birth, highest_qualification, marks_obtained, goals, email_id, scheduled_program_id,status) VALUES(?,?,?,?,?,?,?,?,?)";

	// Fetching Application Details Using scheduled Program Id
	public final String GETAPPLICATIONSQUERY = "SELECT application_id, full_name,date_of_birth,highest_qualification,marks_obtained,goals,email_id,scheduled_program_id,status,date_of_interview FROM application WHERE scheduled_program_id=?";

	// Query to Update Application Status
	public final String UPDATESTATUS = "UPDATE application SET status=?, date_of_interview=? WHERE application_id=?";
	
	

	// View scheduled Program
	public final String VIEWPROGRAMSCHEDULE = "SELECT Scheduled_program_id,programName,Location,Start_date,end_date,sessions_per_week FROM programs_scheduled";

	// View Application Details
	public final String VIEWALLAPPLICATIONS = "SELECT application_id,full_name,date_of_birth,highest_qualification,marks_obtained,goals,email_id,scheduled_program_id,status,date_of_interview FROM application";

	// Insert Into Program Schedule 
	public final String ADDTOSCHEDULE = "INSERT INTO programs_scheduled VALUES (scheduled_pgm_seq.NEXTVAL,?,?,?,?,?)";

	//Fetching Scheduled Program Id
	public final String SCHEDULEDPGMID = "SELECT scheduled_program_id , programname FROM program_scheduled";

	public final String VIEWAPPLICATIONSTATUS = "SELECT Application_id,full_name,date_of_birth,highest_qualification,marks_obtained,goals,email_id,scheduled_program_id,status,date_of_interview fROM Application WHERE Application_id=?";

	public final String VIEWPGMSOFFERED = "SELECT programname,description,applicant_eligibility,duration,degree_certificate_offered FROM programs_offered";

	public final String PROGRAMSCHEDULEDBYDATE = "SELECT scheduled_program_id,programname,location, start_date, end_date, sessions_per_week FROM programs_scheduled WHERE start_date >= ?  AND end_date <= ?";

	public final String DELETEPROGRAMOFFERED = "DELETE FROM programs_offered WHERE programname=?";

	public final String DELETEPROGRAMSCHEDULED = "DELETE FROM programs_scheduled WHERE scheduled_program_id=?";

	public final String UPDATEPROGRAMSOFFERED = "UPDATE programs_offered SET description=?, applicant_eligibility=? WHERE programname=?";

	public final String GETALLDETAILS = "SELECT scheduled.programname,scheduled.location,scheduled.start_date,scheduled.end_date,scheduled.sessions_per_week,offered.description,offered.applicant_eligibility,offered.duration,offered.degree_certificate_offered FROM programs_scheduled scheduled, programs_offered offered WHERE offered.programname=scheduled.programname";

	public final String ADDTOOFFERED = "INSERT INTO programs_offered VALUES (?,?,?,?,?)";
}
