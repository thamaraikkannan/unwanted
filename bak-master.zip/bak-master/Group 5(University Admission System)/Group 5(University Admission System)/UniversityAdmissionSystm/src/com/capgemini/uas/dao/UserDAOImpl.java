package com.capgemini.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.uas.bean.User;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.util.DBConnection;

public class UserDAOImpl implements IUserDAO {

	private Logger log = Logger.getLogger("UserDAO");

	@Override
	public User getUserByName(String userName) throws UASException {
		User user = null;
		try (Connection con = DBConnection.getInstance().getConnection();
				PreparedStatement st = con
						.prepareStatement(IQueryMapper.GETUSER)) {

			st.setString(1, userName);

			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setUserName(rs.getString(1));
				user.setPassword(rs.getString(2));
				user.setRole(rs.getString(3));
			}
		} catch (SQLException e) {
			log.error(e);
			throw new UASException("Unable To FEtch Records");
		}
		return user;
	}

}
