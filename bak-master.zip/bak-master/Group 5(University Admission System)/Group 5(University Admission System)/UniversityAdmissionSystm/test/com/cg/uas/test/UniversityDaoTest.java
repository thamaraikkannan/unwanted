package com.cg.uas.test;
import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ApplicationStatus;
import com.capgemini.uas.dao.UniversityDAOImpl;
import com.capgemini.uas.dao.UserDAOImpl;
import com.capgemini.uas.exception.UASException;

public class UniversityDaoTest {
	static UniversityDAOImpl universityDao;
	static UserDAOImpl userDao;
	static Application application;
	static ApplicationStatus applicationStatus;
	
	@BeforeClass
	public static void initialize() {
		universityDao = new UniversityDAOImpl(); 
		 userDao=new UserDAOImpl();
		application = new Application();
		application = new Application();
		
		
}
	
	@Test
	public void testAddApplicationDetails() throws UASException{
		application.setApplicationId("1001");
		application.setFullName("Bhargav Nadimpalli");
		application.setDateOfBirth("26-05-1996");
		application.setHighestQualification("B.Tech");
		application.setMarksObtained("90");
		application.setGoals("Distiction");
		application.setEmailID("nadimpallibhargav@gmail.com");
		application.setScheduledProgramID("101");
		application.setStatus("open");
	}
	
	
}
