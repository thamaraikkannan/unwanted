package com.cg.service;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;





import com.cg.dao.TraineeDao;
import com.cg.dto.Login;
import com.cg.dto.Trainee;
@Service("service")
public class TraineeServiceImpl implements TraineeService
{

	
	@Autowired
	TraineeDao dao;
	
	public TraineeDao getDao() {
		return dao;
	}

	public void setDao(TraineeDao dao) {
		this.dao = dao;
	}

	@Override
	public boolean isUserExist(String unm) {
		
		return dao.isUserExist(unm);
	}

	@Override
	public boolean isValid(Login log) {
		
		return dao.isValid(log);
	}

	@Override
	public Trainee addTrainee(Trainee tr1) {
		// TODO Auto-generated method stub
		return dao.addTrainee(tr1);
	}

	@Override
	public Trainee deleteTrainee(int id) {
		
		
		return dao.deleteTrainee(id);
	}

	@Override
	public Trainee searchTrainee(int id) {
	
		return dao.searchTrainee(id);
	}

	@Override
	public ArrayList<Trainee> getAllUsers() {
		
		return dao.getAllUsers();
	}

	@Override
	public Trainee modifyDetails(Trainee trr) {
	
		return dao.modifyDetails(trr);
	}
	

}
