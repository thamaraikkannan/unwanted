package com.cg.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Login;

import com.cg.dto.Trainee;
import com.cg.service.TraineeService;

@Controller

public class LoginController 
{

	@Autowired
	TraineeService service;
	ArrayList<String> domainList=null;
	
	@RequestMapping(value="/ShowIndexPage",method=RequestMethod.GET)
	public String showIndexPage(Model model)
	{
		Login lg=new Login();
		model.addAttribute("Login", lg);
		
		return "Index";
	}
	
	
	
	public TraineeService getService() {
		return service;
	}



	public void setService(TraineeService service) {
		this.service = service;
	}



	@RequestMapping(value="/Validate",method=RequestMethod.GET)
	public String Validate(@Valid@ModelAttribute("Login") Login lgg,BindingResult result,Model model)
	{
		

		if(result.hasErrors())
		{
			return "Index";
		}
		
		else
		{
		String un=lgg.getUsername();
		//String pw=lgg.getPassword();
		if(service.isUserExist(un))
		{
			if(service.isValid(lgg))
			{
				
				return "Success";
			}
			else
			{
				String msg="Password Does Not Exist";
				model.addAttribute("error", msg);
				return "Error";
			}
		}
		else
		{
			String msg="User ID Does Not Exist";
			model.addAttribute("error", msg);
			//return "Register";
			return "Error";
		}
		}
		
	}
	
	
	@RequestMapping(value="/addtrainee",method=RequestMethod.GET)
	public String addTrainee(Model model)
	{
		Trainee tr=new Trainee();
		
		
		
		domainList=new ArrayList<String> ();
		domainList.add("Java");
		domainList.add("Oracle");
		domainList.add("BIGDATA");
		domainList.add(".NET");
		model.addAttribute("addtrainee", tr);
		model.addAttribute("dList", domainList);
		return "AddTrainee";
	}
	
	@RequestMapping(value="/addedTrainee",method=RequestMethod.GET)
	public String addTraineeDetails(@ModelAttribute(value="addtrainee") Trainee tr1,Model model)
	{
		
		Trainee tr= service.addTrainee(tr1);
		
		model.addAttribute("trainee",tr);
		return "AddedTrainee";
	}
	
	@RequestMapping(value="/deletetrainee",method=RequestMethod.GET)
	public String deletetrainee(Model model)
	{
		
		return "Delete";
		
	}
	
	@RequestMapping(value="/deleteTrainee",method=RequestMethod.GET)
	public String deletedTrainee(@RequestParam(value="id") int id,Model model)
	{
		Trainee tr1=service.searchTrainee(id);
		model.addAttribute("tr1",tr1);
		Trainee tr2=service.searchTrainee(id);
	
	
		return "Deleted";
		
	}
	
	@RequestMapping(value="/retrievetrainee",method=RequestMethod.GET)
	public String retrievetrainee(Model model)
	{
		
		return "Retrieve";
		
	}
	
	@RequestMapping(value="/RetrieveTrainee",method=RequestMethod.GET)
	public String retrieveTrainee(@RequestParam(value="id") int id,Model model)
	{
		Trainee tr1=service.searchTrainee(id);
		model.addAttribute("tr1",tr1);
		
		return "Retrieved";
		
	}
	@RequestMapping(value="/viewall",method=RequestMethod.GET)
	public String viewAll(Model model)
	{

		ArrayList<Trainee> usr=service.getAllUsers();
		model.addAttribute("UserListObj", usr);


		return "ListAllUsers";
	}
	
	@RequestMapping(value="/modifytrainee",method=RequestMethod.GET)
	public String modifyTrainee(Model model)
	{
		return "Modify";
	}
	
	@RequestMapping(value="/modifyTrainee",method=RequestMethod.GET)
	public String modifiedTrainee(@RequestParam(value="id") int id,Model model)
	{
		Trainee tr1=service.searchTrainee(id);
		
		int id1=tr1.getTraineeId();
		String name=tr1.getTraineeName();
		String location=tr1.getTraineeLocation();
		String domain=tr1.getTraineeDomain();
		
		Trainee te1=new Trainee();
		model.addAttribute("modify", te1);
		model.addAttribute("id1", id1);
		model.addAttribute("name", name);
		model.addAttribute("location", location);
		model.addAttribute("domain", domain);
		
		return "ModifyDetails";
		
	}
	
	@RequestMapping(value="/modified",method=RequestMethod.GET)
	public String modifyDetails(@ModelAttribute(value="modify") Trainee tr5,Model model)
	{
			
		service.modifyDetails(tr5);
		
		return "redirect:/viewall.obj";
		
	}
	
	@RequestMapping(value="/deleted",method=RequestMethod.GET)
	public String deleteDetails(@RequestParam(value="tr1") int id,Model model)
	{
			
		service.deleteTrainee(id);
		
		return "redirect:/viewall.obj";
		
	}
	
}
