package com.cg.hms.controller;

import java.util.ArrayList;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.hms.dto.HotelBean;
import com.cg.hms.dto.RegisterBean;
import com.cg.hms.service.IService;

@Controller
public class HMSCtrl
{
	@Autowired
	IService service;


	public IService getService() {
		return service;
	}


	public void setService(IService service) {
		this.service = service;
	}


	@RequestMapping(value="/ShowIndexPage",method=RequestMethod.GET)
	public String viewAll(Model  model)
	{

		ArrayList<HotelBean> usr=service.viewAllDetails();
		model.addAttribute("hotelListObj", usr);


		return "Index";

	}

	@RequestMapping(value="/booknow",method=RequestMethod.GET)
	public String bookHotel(@RequestParam (value="hid") String hid,@RequestParam (value="hname") String hname,@RequestParam (value="rooms") String rooms, Model model)
	{
		RegisterBean bean= new RegisterBean();
		model.addAttribute("hid", hid);
		model.addAttribute("hname", hname);
		//model.addAttribute("rooms", rooms);
		//bean.setToDate("mm/dd/yyyy");
		model.addAttribute("bean", bean);
		return "Register";	
	}

	@RequestMapping(value="/Success",method=RequestMethod.POST)
	public String validateUser(@Valid@ModelAttribute("bean")RegisterBean bean,BindingResult result,Model model)
	{

		if(result.hasErrors())
		{
			return "Register";
		}
		else{
			RegisterBean bean1= new RegisterBean();
			System.out.println(bean);
			/*Calendar cal= Calendar.getInstance();
		Calendar cal1= Calendar.getInstance();// calendat instance creation.
		bean.setFromDate(cal.getTime());
		bean.setToDate(cal1.getTime());
		DateFormat formatdate=new SimpleDateFormat("yyyy-mm-dd");
		try {
			Date formateddate=(Date)formatdate.parse("bean.getFromDate()");
			bean.setFromDate(formateddate);
			Date formateddate1=(Date)formatdate.parse("bean.getTODate()");
			bean.setToDate(formateddate1);
		} catch (ParseException e) {

			//e.printStackTrace();
		}*/
			bean1=service.addDetails(bean);
			model.addAttribute("successObj", bean1);
			return "Success";
		}
	}

}

