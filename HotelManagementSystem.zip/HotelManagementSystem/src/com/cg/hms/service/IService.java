package com.cg.hms.service;

import java.util.ArrayList;

import com.cg.hms.dto.HotelBean;
import com.cg.hms.dto.RegisterBean;

public interface IService
{
	public ArrayList<HotelBean> viewAllDetails();

	public RegisterBean addDetails(RegisterBean bean);
}
