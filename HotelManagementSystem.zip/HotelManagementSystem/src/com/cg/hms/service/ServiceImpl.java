package com.cg.hms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hms.dao.IDao;
import com.cg.hms.dto.HotelBean;
import com.cg.hms.dto.RegisterBean;

@Service("service")
public class ServiceImpl implements IService
{

	@Autowired
	IDao dao;
	
	
	public IDao getDao() {
		return dao;
	}


	public void setDao(IDao dao) {
		this.dao = dao;
	}


	@Override
	public ArrayList<HotelBean> viewAllDetails() {
		
		return dao.viewAllDetails();
	}


	@Override
	public RegisterBean addDetails(RegisterBean bean) {
		
		return dao.addDetails(bean);
	}

}
