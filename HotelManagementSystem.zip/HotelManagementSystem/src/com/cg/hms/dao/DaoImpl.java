package com.cg.hms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.hms.dto.HotelBean;
import com.cg.hms.dto.RegisterBean;

@Repository("dao")
@Transactional
public class DaoImpl implements IDao
{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public ArrayList<HotelBean> viewAllDetails() {
		

		String qry="select reg from HotelBean reg";
		TypedQuery<HotelBean> tq=entityManager.createQuery(qry,HotelBean.class);
		ArrayList<HotelBean> hotelL=(ArrayList)tq.getResultList();
		
		return hotelL;
		
		
	}

	@Override
	public RegisterBean addDetails(RegisterBean bean) 
	{
		
		entityManager.persist(bean);
		entityManager.flush();
		
		return bean;
	}

	
	
}
