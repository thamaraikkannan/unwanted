package com.cg.ma.service;

import java.util.List;

import com.cg.ma.bean.Assessmentbean;
import com.cg.ma.bean.TraineeBean;
import com.cg.ma.dao.Dao;
import com.cg.ma.dao.Idao;
import com.cg.ma.exception.ModuleException;

public class Service  implements IService{

	Idao dao=new Dao();
	
	@Override
	public Assessmentbean adddetails(Assessmentbean bean)
			throws ModuleException {
		// TODO Auto-generated method stub
		return dao.adddetails(bean);
	}

	@Override
	public List<TraineeBean> getid() throws ModuleException {
		// TODO Auto-generated method stub
		return dao.getid();
	}

}
