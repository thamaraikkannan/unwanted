package com.cg.ma.dao;

public interface IQueryMapper {

	public static final String INSERT_QRY="insert into assessment_details values(?,?,?,?,?)";
	
	public static final String SELECT_QRY="select traineeid from trainees";
}
