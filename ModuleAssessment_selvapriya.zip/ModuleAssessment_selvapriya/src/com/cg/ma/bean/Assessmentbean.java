package com.cg.ma.bean;

public class Assessmentbean {

	private int traineeId;
	private String moduleName;
	private int mpt;
	private int mtt;
	private int assign;
	
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public int getMpt() {
		return mpt;
	}
	public void setMpt(int mpt) {
		this.mpt = mpt;
	}
	public int getMtt() {
		return mtt;
	}
	public void setMtt(int mtt) {
		this.mtt = mtt;
	}
	public int getAssign() {
		return assign;
	}
	public void setAssign(int assign) {
		this.assign = assign;
	}
	
	
	
}
